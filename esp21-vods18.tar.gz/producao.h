#ifndef PRODUCAO_H
#define PRODUCAO_H

void lp_solve_format(int n, int m, double* precos, double** compostos, double** quantidades);

#endif